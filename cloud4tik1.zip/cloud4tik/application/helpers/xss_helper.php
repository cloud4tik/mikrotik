<?php

function cetak($str) {
    return htmlentities($str, ENT_QUOTES, 'UTF-8');
}
