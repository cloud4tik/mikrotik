<!-- /.content-wrapper -->
<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.3.0
    </div>
    <strong>Copyright &copy; 2018 <a href="javascript:void(0)">Cloud4Tik</a>.</strong> All rights reserved. Powered by Mikrostator
</footer>

<!-- ./wrapper -->


<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
    $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.7 -->
<script src="<?= base_url('assets/js/bootstrap.min.js') ?>"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="<?= base_url('assets/js/bootstrap3-wysihtml5.all.min.js') ?>"></script>
<!-- AdminLTE App -->
<script src="<?= base_url('assets/js/adminlte.min.js') ?>"></script>
<!-- AdminLTE dashboard -->
<script src="<?= base_url('assets/js/dashboard.js') ?>"></script>
<!-- DataTables -->
<script src="<?= base_url('assets/js/jquery.dataTables.min.js') ?>"></script>
<script src="<?= base_url('assets/js/jquery.slimscroll.min.js') ?>"></script>
<script src="<?= base_url('assets/js/dataTables.bootstrap.min.js') ?>"></script>
<script src="<?= base_url('assets/js/dataTables.responsive.js') ?>"></script>
<script src="<?= base_url('assets/js/dataTables.buttons.min.js') ?>"></script>
<script src="<?= base_url('assets/js/buttons.flash.min.js') ?>"></script>

<script src="<?= base_url('assets/js/jszip.min.js') ?>"></script>
<script src="<?= base_url('assets/js/pdfmake.min.js') ?>"></script>
<script src="<?= base_url('assets/js/vfs_fonts.js') ?>"></script>
<script src="<?= base_url('assets/js/buttons.html5.min.js') ?>"></script>
<script src="<?= base_url('assets/js/buttons.print.min.js') ?>"></script>
<!-- Plugins -->
<script src="<?= base_url('assets/js/dataTables.colVis.min.js') ?>"></script>
<script src="<?= base_url('assets/js/buttons.colVis.min.js') ?>"></script>
<script src="<?= base_url('assets/js/buttons.bootstrap.min.js') ?>"></script>
<script src="<?= base_url('assets/js/bootstrap3-wysihtml5.all.min.js') ?>"></script>
<script src="<?= base_url('assets/js/select2.full.min.js') ?>"></script>

</body>
</html>
