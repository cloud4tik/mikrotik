<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">    
    <!-- Main content -->
    <section class="content">

        <!-- Main row -->
        <div class="row">
            <!-- Single col -->
            <section class="col-lg-12 connectedSortable" id="mikrostator-section">
                
            </section>
            <!-- /.Single col -->
        </div>
        <!-- /.row (main row) -->



        <!-- Main row -->
        <div class="row">
            <!-- Left col -->
            <section class="col-lg-6 connectedSortable">
                
            </section>
            <!-- /.Left col -->



            <!-- right col (We are only adding the ID to make the widgets sortable)-->
            <section class="col-lg-6 connectedSortable">
                
            </section>
            <!-- right col -->
        </div>
        <!-- /.row (main row) -->

        <!-- Main row -->
        <div class="row">
            
            </section>
            <!-- /.Left col -->


            <!-- Center col -->
            <section class="col-lg-4 connectedSortable">
                
            </section>
            <!-- /.Center col -->



            <!-- right col (We are only adding the ID to make the widgets sortable)-->
            <section class="col-lg-4 connectedSortable">
                
            </section>
            <!-- right col -->
        </div>
        <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
</div>
